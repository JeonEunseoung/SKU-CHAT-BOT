package com.example.skuchatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkuchatbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
